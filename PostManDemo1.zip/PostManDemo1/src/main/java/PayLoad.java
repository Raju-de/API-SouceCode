
public class PayLoad {
	
	public static String loginDetail() {
		return "{\r\n" + 
				"	\"email\":\"support@app2food.com\",\r\n" + 
				"	\"password\":\"rome123\"\r\n" + 
				"}";
	}
	
	public static String forgotPassword() {
		return "{\r\n" + 
				" \"email\": \"support@app2food.com\"}\r\n";
	}
	public static String verifyPassword() 
	{
		return "{\r\n" + 
				"	\"email\":\"support@app2food.com\",\r\n" + 
				"	\"vcode\":\"rome123\"\r\n" + 
				"}";	
}
	public static String resetPassword() 
	{
		return "{\r\n" + 
				"	\"email\":\"support@app2food.com\",\r\n" + 
				"	\"npass\":\"rome123\",\r\n" + 
				"	\"pass\":\"rome123\"\r\n" + 
				"	\r\n" + 
				"}";	
}
	public static String graphs() 
	{
		return "{\r\n" + 
				"	\"supervisor_id\":\"228\",\r\n" + 
				"	\"store_id\":\"11002\"\r\n" + 
				"}";	
	}
	public static String order() 
	{
		return "{\r\n" + 
				"	\"page\":\"100\",\r\n" + 
				"	\"sice\":\"10\",\r\n" + 
				"	\"supervisor_id\":\"228\",\r\n" + 
				"	\"store_id\":\"11002\"\r\n" + 
				"}";	
	}
	public static String orderDetails() 
	{
		return "{\r\n" + 
				"	\"supervisor_id\":\"228\",\r\n" + 
				"	\"order_id\":\"{{order_id}}\"\r\n" + 
				"}";	
	}
	public static String searChorder() 
	{
		return "{{\r\n" +  
				"	\"store_id\":\"11002\",\r\n" + 
				"\"order_id:,\r\n" + 
				"supervisor_id\":\"228\",\r\n" + 
				"\"store_name:,\r\n" + 
				"order_status:,\r\n" + 
				"order_type:,\r\n" + 
				"payment_mode:,\r\n" + 
				"page\":\"1\",\r\n" + 
				"\"size\":\"10\"\r\n" + 
				"}";	
	}
	public static String basicDetails() 
	{
		return "{\r\n" + 
				"	\"store_id\":\"11002\",\r\n" + 
				"	\"supervisor_id\":\"228\"\r\n" + 
				"}";	
	}
	public static String updateBasicDetails() 
	{
		return "{{\r\n" + 
				"\"store_id\":\"11002\",\r\n" + 
				"\"supervisor_id\":318,\r\n" + 
				"\"basic_details\":\r\n" + 
				"{\"company_name\":\"US Company Names\",\r\n" + 
				"\"store_name\":\"Demo Restaurant-App2food\",\r\n" + 
				"\"owner_phone\":\"8860822306\",\r\n" + 
				"\"owner_email\":\"rohit@app2mobile.com\",\r\n" + 
				"\"address\":{\"street_address\":\"343, Millburn Avenue\",\r\n" + 
				"\"city_name\":\"Millburn\",\r\n" + 
				"\"state_code\":\"NJ\",\r\n" + 
				"\"country_code\":\"US\",\r\n" + 
				"\"store_pincode\":\"07041\",\r\n" + 
				"\"longitude\":\"\",\r\n" + 
				"\"latitude\":\"\"\r\n" + 
				"}}}";
	}
	public static String menu() 
	{
		return "{\r\n" + 
				"	\"store_id\":\"11002\",\r\n" + 
				"	\"supervisor_id\":\"228\"\r\n" +
				"	\"menu_id\":\"2\"\r\n" +
				"}";
}
}
