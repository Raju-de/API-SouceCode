
public class Constants {

	public static final String BASEURL="https://stg.app2food.com/panel30/api/v3";
	public static final String HEADERCONTENT="Content-Type";
	public static final String HEADERJSON="application/json";
	public static final String RESOURCELOGIN="/user/login";
	public static final String URL="URL";
	public static final String RESOURCEFORGOTLOGIN="user/forgotlogin";
	public static final String RESOURCVERIFYPASSWORD="user/verifypasswordcode";
	public static final String RESOURCRESETPASSWORD="user/resetpassword";
	public static final String RESOURCREGRAPHS="store/graphs";
	public static final String RESOURCREORDER="store/orders";
	public static final String RESOURCREORDERDETAILS="store/orderdetails";
	public static final String RESOURCRESEARCHORDER="store/searchorder";
	public static final String RESOURCREBASICDETAILS="store/basicdetails";
	public static final String RESOURCREMENU="store/menu";	
}
