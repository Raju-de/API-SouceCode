package config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public  class Base {
	public static Properties prop;
	public static String baseURL() throws IOException{
			prop = new Properties();
			FileInputStream fis = new FileInputStream (System.getProperty("user.dir")+"\\src\\main\\java\\config"
					+ "\\testconfig.properties" );
			prop.load(fis);
			final String  basrUrl= prop.getProperty("URL");
			System.out.println("basrUrl" + basrUrl);
			return basrUrl;
	}
}
