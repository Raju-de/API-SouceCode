import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import java.io.IOException;
import config.Base;
import io.restassured.RestAssured;
public class Postman {

	@Test
	public void login() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.body(PayLoad.loginDetail()).when().post(Constants.RESOURCELOGIN).then().log().all().assertThat()
				.statusCode(200).body("msg", equalTo("")).extract().response().asString();
		System.out.println(response);
	}

	@Test
	public void forgotlogin() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.body(PayLoad.forgotPassword()).when().post(Constants.RESOURCEFORGOTLOGIN).then().assertThat()
				.statusCode(200).extract().response().asString();
		System.out.println(response);
	}

	@Test
	public void verifypasswordcode() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.body(PayLoad.verifyPassword()).when().post(Constants.RESOURCVERIFYPASSWORD).then().assertThat()
				.statusCode(200).extract().response().asString();
		System.out.println(response);
	}

	@Test
	public void resetPassword() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.body(PayLoad.resetPassword()).when().post(Constants.RESOURCRESETPASSWORD).then().assertThat()
				.statusCode(200).body("msg", equalTo("New password is same as the old password..!")).extract()
				.response().asString();
		System.out.println(response);
	}

	@Test
	public void graph() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4").body(PayLoad.graphs()).when()
				.post(Constants.RESOURCREGRAPHS).then().assertThat().statusCode(401).extract().response().asString();
		System.out.println(response);
	}

	@Test
	public void order() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().header(Constants.HEADERCONTENT, Constants.HEADERJSON)
				.queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4").body(PayLoad.order()).when()
				.post(Constants.RESOURCREORDERDETAILS).then().assertThat().statusCode(200).extract().response()
				.asString();
		System.out.println(response);
	}

	@Test
	public void orderDetails() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4")
				.header(Constants.HEADERCONTENT, Constants.HEADERJSON).body(PayLoad.orderDetails()).when()
				.post(Constants.RESOURCREORDERDETAILS).then().assertThat().statusCode(200).extract().response()
				.asString();
		System.out.println(response);
	}

	@Test
	public void searChorder() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4")
				.header(Constants.HEADERCONTENT, Constants.HEADERJSON).body(PayLoad.orderDetails()).when()
				.post(Constants.RESOURCRESEARCHORDER).then().assertThat().statusCode(200).extract().response()
				.asString();
		System.out.println(response);
	}

	@Test
	public void basicDetails() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4")
				.header(Constants.HEADERCONTENT, Constants.HEADERJSON).body(PayLoad.basicDetails()).when()
				.post(Constants.RESOURCRESEARCHORDER).then().assertThat().statusCode(200).extract().response()
				.asString();
		System.out.println(response);
	}

	@Test
	public void updateBasicDetails() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4")
				.header(Constants.HEADERCONTENT, Constants.HEADERJSON).body(PayLoad.updateBasicDetails()).when()
				.post(Constants.RESOURCREBASICDETAILS).then().assertThat().statusCode(200).extract().response()
				.asString();
		System.out.println(response);
	}

	@Test
	public void menu() throws IOException {
		RestAssured.baseURI = Base.baseURL();
		String response = given().log().all().queryParam("access_token", "aacac85659fb46e6694a114c748f90bb8f1b1af4")
				.header(Constants.HEADERCONTENT, Constants.HEADERJSON).body(PayLoad.menu()).when()
				.post(Constants.RESOURCREMENU).then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(response);
	}
}
